A 2D Maze Generator for Unity.

Will generate a 2D Maze using Sprites provided 
Contains a 2x2 Centre room as the starting point.
An exit will be placed on one of the edge Cells.

For usage and info, see the provided PDF 'Setting up the Generator'.
See the example image for an example of a 20x20 Cell Maze generation.